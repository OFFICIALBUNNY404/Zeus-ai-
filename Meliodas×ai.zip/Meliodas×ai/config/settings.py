# Konfigurasi MeliodasxAi
# Ganti dengan kredensial Anda

class Config:
    # Kunci API DeepSeek (TANAMKAN LANGSUNG)
    DEEPSEEK_API_KEY = "sk-1a87fbfb236145e6ac47fac34eae976f"
    
    # Nama pencipta untuk protokol kesetiaan
    CREATOR_NAME = "Zeus×Storngs"  # Ganti dengan nama Anda
    
    # Endpoint API DeepSeek (tanpa filter)
    DEEPSEEK_API_URL = "https://api.deepseek.com/v1/chat/completions"
    
    # Mode operasi: 'production' untuk penggunaan normal
    MODE = "production"